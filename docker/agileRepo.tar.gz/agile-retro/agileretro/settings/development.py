from .common import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

# Database
# https://docs.djangoproject.com/en/2.1/ref/settings/#databases

EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

