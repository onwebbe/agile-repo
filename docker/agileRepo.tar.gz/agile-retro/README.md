# AgileRetro
A continuous retrospective system based on python.
